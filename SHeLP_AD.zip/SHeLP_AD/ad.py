import paramiko
from flask import Flask, render_template, request, flash
import logging
from logging.handlers import RotatingFileHandler
from cryptography.fernet import Fernet
import json
# from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
#import password

__author__ = "Tejas.S"
__copyright__ = "Copyright 2020, Quotient"
__version__ = "1.0"
__maintainer__ = "Tejas.S"
__email__ = "ts@quotient.com"
__status__ = "Staging"

app = Flask(__name__)
app.secret_key = "TZX"

# initilizing ssh client object
ssh_client = paramiko.SSHClient()
ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# logging
logger = logging.getLogger('shelplogger')
logging.basicConfig(
    handlers=[RotatingFileHandler('shelp.log', maxBytes=100000, backupCount=10)],
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s",
    datefmt='%Y-%m-%dT%H:%M:%S')
#decrypt password files

with open("key.enc", "rb")as file_key:
    cipher = file_key.read()

cipher = Fernet(cipher)
with open("encoded_pass.enc", "rb")as file_dec:
    dc_decrypt = file_dec.read()
data_DC = cipher.decrypt(dc_decrypt).decode('utf-8')
#rpass_dict = data_DC
rpass_dict = json.loads(data_DC)
with open("encoded_gc_pass.enc", "rb")as file_gc:
    gc_decrypt = file_gc.read()
data_GC = cipher.decrypt(gc_decrypt).decode('utf-8')
#gcuser_dict = data_GC
gcuser_dict = json.loads(data_GC)


# render home page
@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('home.html')


# User console : this section takes inputs for adflush and reload by user and passes to next function
@app.route('/adflush_reload', methods=['GET', 'POST'])
def flush_reload():
    if request.method == 'POST':
        hostname = request.form['IP']
        host = hostname[3:5]
        username = request.form['username']
        domain = request.form['domain']
        app.logger.info(
            'User inputs for adflush and reload ' + ' hostIP:' + hostname + ', username:' + username + ', domain:' + domain)
        establish_connection(host, hostname)
        app.logger.critical('Info: connection established to ' + hostname + ' by ' + username)
        log = adflush_reload(username, domain)
        app.logger.critical('Info: Adflush and reload completed for ' + hostname + ' by ' + username + str(log))
        flash("adflush and reload, check your login now", "warning")
        # flash("Home directory is now refreshed", "warning")
    return render_template('home.html')


# Admin console : this section takes inputs from admin user for adleave and join
@app.route('/admin/lj', methods=['GET', 'POST'])
def leave_join():
    if request.method == 'POST':
        hostname = request.form['IP']
        host = hostname[3:5]
        username = request.form['username']
        domain = request.form['domain']
        app.logger.info(
            'User inputs for adleave and join ' + ' hostIP:' + hostname + ', username:' + username + ', domain:' + domain)
        establish_connection(host, hostname)
        app.logger.critical('Info: connection established to ' + hostname + ' by ' + username)
        adleave_adjoin(domain, username, hostname)
        app.logger.critical('Info: adleave and join completed for ' + hostname + ' by ' + username)
        flash("leave and join completed", "warning")
    return render_template('admin.html')


# In this section we establish the ssh connection
def establish_connection(host, hostname):
    global status
    if '30' in host:  # try password for Sc5 hosts
        for key, value in rpass_dict.items():
            if key == 'SC5':
                for x in rpass_dict.get('SC5'):
                    # print (x, hostname)
                    try:
                        ssh_client.connect(hostname=hostname, username='root', password=x)
                        break
                    except:
                        status = 'this pass did not work, please wait while we try other password'
                        pass
    if '40' in host:  # try passwords for LV1 hosts
        for key, value in rpass_dict.items():
            if key == 'LV1':
                for x in rpass_dict.get('LV1'):
                    # print (x, hostname)
                    try:
                        ssh_client.connect(hostname=hostname, username='root', password=x)
                        break
                    except:
                        status = 'this pass did not work, please wait while we try other password'
                    pass
    if '35' in host:  # try passwords for SFO hosts
        for key, value in rpass_dict.items():
            if key == 'SFO':
                for x in rpass_dict.get('SFO'):
                    # print (x, hostname)
                    try:
                        ssh_client.connect(hostname=hostname, username='root', password=x)
                        break
                    except:
                        status = 'this pass did not work, please wait while we try other password'
                    pass
    if '36' in host:  # try passwords for PDN hosts
        for key, value in rpass_dict.items():
            if key == 'SFO':
                for x in rpass_dict.get('SFO'):
                    # print (x, hostname)
                    try:
                        ssh_client.connect(hostname=hostname, username='root', password=x)
                        break
                    except:
                        status = 'this pass did not work, please wait while we try other password'
                    pass
    if '55' in host:  # try passwords for DCA hosts
        for key, value in rpass_dict.items():
            if key == 'DCA':
                for x in rpass_dict.get('DCA'):
                    # print (x, hostname)
                    try:
                        ssh_client.connect(hostname=hostname, username='root', password=x)
                        break
                    except:
                        status = 'this pass did not work, please wait while we try other password'
                    pass
    else:
        status = "please enter correct host IP"
    return status


# to perform AD flush and AD reload operations
def adflush_reload(username, domain):
    stdin, stdout, stderr = ssh_client.exec_command("adflush")
    log = stdout.readlines()
    stdin, stdout, stderr = ssh_client.exec_command("adreload")
    if len(domain) == len('corp.coupons.com'):
        stdin, stdout, stderr = ssh_client.exec_command(r"id coupons\\" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
    elif len(domain) == len('sc5.coupons.lan'):
        stdin, stdout, stderr = ssh_client.exec_command(r"id coupons\\" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
    elif len(domain) == len('lv1.coupons.lan'):
        stdin, stdout, stderr = ssh_client.exec_command(r"id coupons\\" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
    else:
        stdin, stdout, stderr = ssh_client.exec_command("id" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
    return log


# to perform adleave and adjoin operations
def adleave_adjoin(domain, username, hostname):
    if len(domain) == len('corp.coupons.com'):
        stdin, stdout, stderr = ssh_client.exec_command("adleave -rf")
        app.logger.critical('Critical: Adleave executed on : ' + hostname + '{{' + str(stdout.readlines()) + '}}')
        app.logger.critical('Critical: joining to domain : ' + domain)
        stdin, stdout, stderr = ssh_client.exec_command(
            "adjoin -w corp.coupons.com -u gcuser -p" + gcuser_dict.get('corp_sc5'))
        app.logger.critical('Critical: Adjoin executed on : ' + hostname + '{{' + str(stdout.readlines()) + '}}')
        stdin, stdout, stderr = ssh_client.exec_command(r"id coupons\\" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
        done = "leave and join complete, check your login now"
    elif len(domain) == len('sc5.coupons.lan'):
        stdin, stdout, stderr = ssh_client.exec_command("adleave -rf")
        app.logger.critical('Critical: Adleave executed on : ' + hostname + '{{' + str(stdout.readlines()) + '}}')
        app.logger.critical('Critical: joining to domain : ' + domain)
        stdin, stdout, stderr = ssh_client.exec_command(
            "adjoin -w sc5.coupons.lan -u gcuser -p" + gcuser_dict.get('corp_sc5'))
        app.logger.critical('Critical: Adjoin executed on : ' + hostname + '{{' + str(stdout.readlines()) + '}}')
        stdin, stdout, stderr = ssh_client.exec_command(r"id coupons\\" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
        done = "leave and join complete, check your login now"
    elif len(domain) == len('lv1.coupons.lan'):
        stdin, stdout, stderr = ssh_client.exec_command("adleave -rf")
        app.logger.critical('Critical: Adleave executed on : ' + hostname + '{{' + str(stdout.readlines()) + '}}')
        app.logger.critical('Critical: joining to domain : ' + domain)
        stdin, stdout, stderr = ssh_client.exec_command(
            "adjoin -w lv1.coupons.lan -u gcuser -p" + gcuser_dict.get('lv1'))
        app.logger.critical('Critical: Adjoin executed on : ' + hostname + '{{' + str(stdout.readlines()) + '}}')
        stdin, stdout, stderr = ssh_client.exec_command(r"id coupons\\" + username)
        app.logger.critical('Info: cache refreshed : ' + '{{' + str(stdout.readlines()) + '}}' + ' for ' + username)
    done = "leave and join complete, check your login now"
    return done


if __name__ == "__main__":
    app.run(threaded=True, host='0.0.0.0', port=4000, debug=True)
