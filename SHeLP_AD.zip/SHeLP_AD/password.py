rpass_dict = dict(SC5=['C9709nsba4!', 'xwr&7DLTSc5', 'xwr&77DLTSc5', 'Pr0dDeV0p$Sc5', 'Sc%n35scal34'],
                  LV1=['xwr&7DLTLv1', 'xwr&77DLTLv1', 'Pr0dDeV0p$Lv1', 'Sc%n35scal34', 'C9709nsba4!'],
                  SFO=['xwr&7DLTSfo', 'xwr&77DLTSfo', 'Pr0dDeV0p$Sfo', 'Sc%n35scal34', 'C9709nsba4!'],
                  DCA=['xwr&7DLTDca', 'xwr&77DLTDca', 'Pr0dDeV0p$Dca', 'Sc%n35scal34', 'C9709nsba4!'])
gcuser_dict = dict(corp_sc5='AddT0D0ma1N', lv1='LV1AddT0D0ma1N', CI='CiLanAddT0D0ma1N')
